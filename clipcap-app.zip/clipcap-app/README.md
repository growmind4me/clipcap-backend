# ClipCap — AI YouTube Shorts Maker

YouTube link দাও → AI best motivational clips খুঁজে বের করে → cut করে দেয়!

## কী কী লাগবে (সব free)

- Python 3.10+
- ffmpeg
- Railway.app account (free)
- GitHub account (free)

---

## Step 1 — Local এ test করো

### Python install করো
```bash
cd backend
pip install -r requirements.txt
```

### ffmpeg install করো
- Windows: https://ffmpeg.org/download.html
- Mac: `brew install ffmpeg`
- Linux: `sudo apt install ffmpeg`

### Backend চালাও
```bash
cd backend
uvicorn main:app --reload
```

Browser এ যাও: http://localhost:8000

---

## Step 2 — Railway তে Deploy করো (Free)

1. **GitHub** এ একটা new repo বানাও
2. `backend` folder এর সব files upload করো
3. **railway.app** এ যাও → Sign up (GitHub দিয়ে)
4. **New Project** → **Deploy from GitHub repo**
5. তোমার repo select করো
6. Railway automatically সব install করবে
7. Deploy হলে একটা URL পাবে: `https://xxx.railway.app`

---

## Step 3 — Frontend Setup

1. `frontend/index.html` file টা browser এ open করো
2. উপরে **API URL** box এ Railway URL paste করো
3. YouTube link দাও → Find Best Clips!

---

## কীভাবে কাজ করে

1. YouTube video download হয় (yt-dlp)
2. Audio transcribe হয় (Whisper AI — free)
3. Motivational keywords দিয়ে best moments খোঁজে
4. ffmpeg দিয়ে clip cut করে
5. তুমি download করো!

---

## Note

- First run এ Whisper model download হবে (~140MB) — একটু সময় লাগবে
- বড় video (1hr+) তে 5-10 মিনিট লাগতে পারে
- Railway free plan এ 500 hours/month পাবে
