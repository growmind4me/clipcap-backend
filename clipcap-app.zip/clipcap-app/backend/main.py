from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
import yt_dlp
import whisper
import ffmpeg
import os
import uuid
import json
import re
from pathlib import Path

app = FastAPI(title="ClipCap API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

DOWNLOAD_DIR = Path("downloads")
CLIPS_DIR = Path("clips")
DOWNLOAD_DIR.mkdir(exist_ok=True)
CLIPS_DIR.mkdir(exist_ok=True)

# Load Whisper model once
print("Loading Whisper model...")
model = whisper.load_model("base")
print("Whisper model loaded!")

# Store job status
jobs = {}

class VideoRequest(BaseModel):
    url: str
    max_clips: int = 5
    max_duration: int = 60  # seconds per clip

class ClipRequest(BaseModel):
    video_id: str
    start: float
    end: float
    caption: str = ""

def get_video_id(url: str) -> str:
    """Extract YouTube video ID"""
    patterns = [
        r'(?:youtube\.com/watch\?v=|youtu\.be/)([^&\n?#]+)',
    ]
    for p in patterns:
        m = re.search(p, url)
        if m:
            return m.group(1)
    return str(uuid.uuid4())[:8]

def download_video(url: str, vid_id: str) -> str:
    """Download YouTube video using yt-dlp"""
    output_path = str(DOWNLOAD_DIR / f"{vid_id}.%(ext)s")
    ydl_opts = {
        'format': 'bestvideo[height<=720]+bestaudio/best[height<=720]',
        'outtmpl': output_path,
        'quiet': True,
        'no_warnings': True,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        title = info.get('title', 'Unknown')
        duration = info.get('duration', 0)

    # Find downloaded file
    for ext in ['mp4', 'webm', 'mkv']:
        path = DOWNLOAD_DIR / f"{vid_id}.{ext}"
        if path.exists():
            return str(path), title, duration

    raise Exception("Download failed")

def transcribe_video(video_path: str) -> list:
    """Transcribe using Whisper and return segments"""
    result = model.transcribe(video_path, language="en")
    return result["segments"]

def find_best_clips(segments: list, max_clips: int = 5, max_dur: int = 60) -> list:
    """Find motivational moments from transcript"""
    motivational_keywords = [
        'success', 'fail', 'never give up', 'believe', 'dream',
        'hard work', 'mindset', 'discipline', 'focus', 'hustle',
        'motivated', 'inspire', 'change', 'grow', 'powerful',
        'winner', 'habit', 'goal', 'vision', 'purpose', 'fight',
        'challenge', 'overcome', 'strong', 'courage', 'fear',
        'the truth', 'remember this', 'listen', 'most people',
        'every single', 'you have to', 'you need to', 'think about',
        'the key', 'secret', 'number one', 'simple', 'real',
    ]

    scored = []
    for i, seg in enumerate(segments):
        text = seg['text'].lower()
        score = sum(1 for kw in motivational_keywords if kw in text)

        # Bonus: short punchy sentences
        words = len(seg['text'].split())
        if 5 <= words <= 25:
            score += 1
        if '!' in seg['text'] or '?' in seg['text']:
            score += 1

        scored.append({
            'index': i,
            'start': seg['start'],
            'end': seg['end'],
            'text': seg['text'].strip(),
            'score': score,
        })

    # Sort by score
    scored.sort(key=lambda x: x['score'], reverse=True)

    # Build clips (group nearby segments)
    clips = []
    used_times = []

    for seg in scored:
        if len(clips) >= max_clips:
            break

        start = max(0, seg['start'] - 2)
        end = seg['end'] + 3

        # Expand to include nearby segments
        for s in segments:
            if start <= s['start'] <= end + 5:
                end = max(end, s['end'])

        # Limit duration
        if end - start > max_dur:
            end = start + max_dur

        # Check overlap
        overlap = any(
            not (end < ut[0] or start > ut[1])
            for ut in used_times
        )
        if overlap:
            continue

        used_times.append((start, end))

        # Collect all text in range
        clip_text = ' '.join(
            s['text'].strip()
            for s in segments
            if start <= s['start'] <= end
        )

        clips.append({
            'id': len(clips) + 1,
            'start': round(start, 1),
            'end': round(end, 1),
            'duration': round(end - start, 1),
            'text': clip_text[:200],
            'score': seg['score'],
            'caption': seg['text'].strip()[:80],
        })

    clips.sort(key=lambda x: x['start'])
    return clips

def cut_clip(video_path: str, start: float, end: float, clip_id: str) -> str:
    """Cut video clip using ffmpeg"""
    output_path = str(CLIPS_DIR / f"{clip_id}.mp4")
    duration = end - start

    (
        ffmpeg
        .input(video_path, ss=start, t=duration)
        .output(
            output_path,
            vcodec='libx264',
            acodec='aac',
            vf='scale=608:1080:force_original_aspect_ratio=decrease,pad=608:1080:(ow-iw)/2:(oh-ih)/2',
            preset='fast',
            crf=23,
        )
        .overwrite_output()
        .run(quiet=True)
    )
    return output_path

def process_video_job(job_id: str, url: str, max_clips: int, max_dur: int):
    """Background job to process video"""
    try:
        jobs[job_id]['status'] = 'downloading'
        jobs[job_id]['message'] = 'Downloading video...'

        vid_id = get_video_id(url)
        video_path, title, duration = download_video(url, vid_id)

        jobs[job_id]['status'] = 'transcribing'
        jobs[job_id]['message'] = 'Transcribing audio with AI...'
        jobs[job_id]['title'] = title
        jobs[job_id]['duration'] = duration
        jobs[job_id]['video_path'] = video_path
        jobs[job_id]['vid_id'] = vid_id

        segments = transcribe_video(video_path)

        jobs[job_id]['status'] = 'analyzing'
        jobs[job_id]['message'] = 'Finding best motivational clips...'

        clips = find_best_clips(segments, max_clips, max_dur)

        jobs[job_id]['status'] = 'done'
        jobs[job_id]['message'] = f'Found {len(clips)} clips!'
        jobs[job_id]['clips'] = clips

    except Exception as e:
        jobs[job_id]['status'] = 'error'
        jobs[job_id]['message'] = str(e)

# ===== ROUTES =====

@app.get("/")
def root():
    return {"message": "ClipCap API running!"}

@app.post("/analyze")
async def analyze_video(req: VideoRequest, bg: BackgroundTasks):
    """Start video analysis"""
    job_id = str(uuid.uuid4())[:8]
    jobs[job_id] = {
        'status': 'starting',
        'message': 'Starting...',
        'clips': [],
        'title': '',
        'duration': 0,
    }
    bg.add_task(
        process_video_job,
        job_id, req.url, req.max_clips, req.max_duration
    )
    return {"job_id": job_id}

@app.get("/status/{job_id}")
def get_status(job_id: str):
    """Check job status"""
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    return jobs[job_id]

@app.post("/cut")
async def cut_video_clip(req: ClipRequest, bg: BackgroundTasks):
    """Cut a specific clip"""
    if req.video_id not in jobs:
        raise HTTPException(404, "Video not found. Analyze first.")

    job = jobs[req.video_id]
    if job['status'] != 'done':
        raise HTTPException(400, "Video not ready yet")

    video_path = job.get('video_path')
    if not video_path or not os.path.exists(video_path):
        raise HTTPException(404, "Video file not found")

    clip_id = str(uuid.uuid4())[:8]
    cut_clip_path = cut_clip(video_path, req.start, req.end, clip_id)

    return {
        "clip_id": clip_id,
        "download_url": f"/download/{clip_id}",
        "message": "Clip ready!"
    }

@app.get("/download/{clip_id}")
def download_clip(clip_id: str):
    """Download a cut clip"""
    path = CLIPS_DIR / f"{clip_id}.mp4"
    if not path.exists():
        raise HTTPException(404, "Clip not found")
    return FileResponse(
        str(path),
        media_type="video/mp4",
        filename=f"clipcap_{clip_id}.mp4"
    )

@app.get("/info")
def get_info(url: str):
    """Get basic video info without downloading"""
    ydl_opts = {'quiet': True, 'no_warnings': True, 'skip_download': True}
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            return {
                "title": info.get('title', ''),
                "duration": info.get('duration', 0),
                "thumbnail": info.get('thumbnail', ''),
                "channel": info.get('uploader', ''),
            }
    except Exception as e:
        raise HTTPException(400, str(e))
